# dep_tregex

Python 2 module that implements Stanford Tregex-inspired language for rule-based dependency tree manipulation.

https://yandex.github.io/dep_tregex/

Bonus: tree visualization into SVG!

![What if Google morhped into GoogleOS?](https://yandex.github.io/dep_tregex/tree.svg)
